-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 28 Okt 2015 pada 03.24
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database_gkr`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_pegawai`
--

CREATE TABLE IF NOT EXISTS `table_pegawai` (
  `NIP` int(11) NOT NULL,
  `Nama` varchar(50) DEFAULT NULL,
  `Jabatan` varchar(30) DEFAULT NULL,
  `Gaji_Pokok` bigint(20) DEFAULT NULL,
  `Potongan` bigint(20) DEFAULT NULL,
  `Tunjangan` bigint(20) DEFAULT NULL,
  `Bonus` bigint(20) DEFAULT NULL,
  `Gaji_Bersih` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_pegawai`
--

INSERT INTO `table_pegawai` (`NIP`, `Nama`, `Jabatan`, `Gaji_Pokok`, `Potongan`, `Tunjangan`, `Bonus`, `Gaji_Bersih`) VALUES
(1001, 'Iqbal Adi Nurmansyah', 'System Analist', 6000000, 150000, 1000000, 20000, 6870000),
(1002, 'Pembayun Rizal', 'DB Design', 4000000, 200200, 1000, 200, 3801000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_pegawai`
--
ALTER TABLE `table_pegawai`
 ADD PRIMARY KEY (`NIP`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
